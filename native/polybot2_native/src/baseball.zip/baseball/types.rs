//! Baseball-specific types. Shared types (GameIdx, TargetIdx, TokenIdx,
//! TargetRegistry, OverLine, SpreadSide, Intent, RawIntent,
//! etc.) live in the crate root (lib.rs).

use crate::{
    GameIdx, InlineStr, Intent, OverLine, SpreadSide, TargetIdx, TargetRegistry, TargetSlot,
    TokenIdx, TokenSlot,
};
use rustc_hash::FxHashMap;
use std::collections::HashSet;
use std::sync::Arc;

#[derive(Clone, Default)]
pub(crate) struct GameTargets {
    pub(crate) over_lines: Vec<OverLine>,
    pub(crate) under_lines: Vec<OverLine>,
    pub(crate) nrfi_yes: Option<TargetIdx>,
    pub(crate) nrfi_no: Option<TargetIdx>,
    pub(crate) moneyline_home: Option<TargetIdx>,
    pub(crate) moneyline_away: Option<TargetIdx>,
    pub(crate) spreads: Vec<SpreadSlot>,
    // F5 (first 5 innings)
    pub(crate) f5_over_lines: Vec<OverLine>,
    pub(crate) f5_under_lines: Vec<OverLine>,
    pub(crate) f5_winner_home: Option<TargetIdx>,
    pub(crate) f5_winner_home_no: Option<TargetIdx>,
    pub(crate) f5_winner_away: Option<TargetIdx>,
    pub(crate) f5_winner_away_no: Option<TargetIdx>,
    pub(crate) f5_winner_draw: Option<TargetIdx>,
    pub(crate) f5_winner_draw_no: Option<TargetIdx>,
    pub(crate) f5_spreads: Vec<SpreadSlot>,
    // Extra innings
    pub(crate) extra_innings_yes: Option<TargetIdx>,
    pub(crate) extra_innings_no: Option<TargetIdx>,
}

#[derive(Clone)]
pub(crate) struct SpreadSlot {
    pub(crate) side: SpreadSide,
    pub(crate) line: f64,
    pub(crate) covers_idx: Option<TargetIdx>,
    pub(crate) not_covers_idx: Option<TargetIdx>,
}

#[cfg(test)]
#[derive(Clone, Default)]
pub(crate) struct Tick {
    pub(crate) universal_id: String,
    pub(crate) goals_home: Option<i64>,
    pub(crate) goals_away: Option<i64>,
    pub(crate) inning_number: Option<i64>,
    pub(crate) inning_half: &'static str,
    pub(crate) match_completed: Option<bool>,
    pub(crate) game_state: &'static str,
}

#[derive(Clone, Copy, Default)]
pub(crate) struct DeltaEvent {
    #[cfg_attr(not(test), allow(dead_code))]
    pub(crate) material_change: bool,
    pub(crate) goal_delta_home: i64,
    pub(crate) goal_delta_away: i64,
}

#[derive(Clone, Default)]
pub(crate) struct StateRow {
    pub(crate) home_score_raw: InlineStr<4>,
    pub(crate) away_score_raw: InlineStr<4>,
    pub(crate) free_text_raw: InlineStr<32>,
    pub(crate) goals_home: Option<i64>,
    pub(crate) goals_away: Option<i64>,
}

#[derive(Clone, Copy, Default)]
pub(crate) struct GameState {
    pub(crate) home: Option<i64>,
    pub(crate) away: Option<i64>,
    pub(crate) total: Option<i64>,
    pub(crate) prev_total: Option<i64>,
    pub(crate) inning_number: Option<i64>,
    pub(crate) inning_half: &'static str,
    pub(crate) match_completed: Option<bool>,
    pub(crate) game_state: &'static str,
    /// BoltOdds outs count (0-3). `None` when last tick was V1.
    pub(crate) outs: Option<u8>,
    /// BoltOdds strikes count (0-3). `None` when last tick was V1.
    pub(crate) strikes: Option<u8>,
    /// BoltOdds base runner state. `None` when last tick was V1.
    pub(crate) base1: Option<bool>,
    pub(crate) base2: Option<bool>,
    pub(crate) base3: Option<bool>,
}

/// BoltOdds-specific dedup row. Integer-based: ball-count-only and
/// strike-count-only changes are filtered out (neither field is in struct).
/// Only outs, inning, half, score, match-completion, and break-status
/// changes pass through.
#[derive(Clone, Copy, Default, PartialEq, Eq)]
pub(crate) struct BoltOddsBaseballRow {
    pub(crate) outs: u8,
    pub(crate) inning: i64,
    pub(crate) top_of_inning: bool,
    pub(crate) home_score: i64,
    pub(crate) away_score: i64,
    pub(crate) match_completed: bool,
    pub(crate) is_break: bool,
}

#[cfg(test)]
pub(crate) struct TickResult {
    pub(crate) game_id: String,
    pub(crate) state: GameState,
    pub(crate) intents: Vec<Intent>,
    pub(crate) material: bool,
}

/// Stack-only result from the live WS tick path. No owned strings,
/// no heap-allocated vectors for the common ≤4-intent case.
pub(crate) struct LiveTickResult {
    pub(crate) game_idx: GameIdx,
    pub(crate) state: GameState,
    pub(crate) intents: smallvec::SmallVec<[Intent; 32]>,
    pub(crate) material: bool,
}

#[cfg_attr(feature = "python-extension", pyo3::prelude::pyclass)]
#[derive(Clone)]
pub(crate) struct NativeMlbEngine {
    pub(crate) game_id_to_idx: FxHashMap<String, GameIdx>,
    pub(crate) game_ids: Vec<String>,
    pub(crate) game_leagues: Vec<Arc<str>>,
    pub(crate) game_targets: Vec<GameTargets>,
    pub(crate) target_slots: Vec<TargetSlot>,
    pub(crate) tokens: Vec<TokenSlot>,
    pub(crate) token_id_to_idx: FxHashMap<String, TokenIdx>,
    pub(crate) strategy_keys: HashSet<String>,
    pub(crate) registry: Option<Arc<TargetRegistry>>,
    pub(crate) kickoff_ts: Vec<Option<i64>>,
    pub(crate) token_ids_by_game: Vec<Vec<String>>,

    pub(crate) has_totals: Vec<bool>,
    pub(crate) has_nrfi: Vec<bool>,
    pub(crate) has_final: Vec<bool>,
    pub(crate) has_f5: Vec<bool>,
    pub(crate) has_extra_innings: Vec<bool>,

    pub(crate) rows: Vec<Option<StateRow>>,
    pub(crate) bo_rows: Vec<Option<BoltOddsBaseballRow>>,
    pub(crate) game_states: Vec<GameState>,

    pub(crate) totals_final_under_emitted: Vec<bool>,
    pub(crate) nrfi_resolved_games: Vec<bool>,
    pub(crate) nrfi_first_inning_observed: Vec<bool>,
    pub(crate) final_resolved_games: Vec<bool>,
    pub(crate) f5_first_five_observed: Vec<bool>,
    pub(crate) f5_top5_fired: Vec<bool>,
    pub(crate) f5_resolved: Vec<bool>,
    pub(crate) f5_total_under_emitted: Vec<bool>,
    pub(crate) extra_innings_resolved: Vec<bool>,
}
